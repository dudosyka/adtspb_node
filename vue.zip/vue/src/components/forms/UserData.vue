<template>

</template>

<script>
export default {
  name: "UserData.vue"
}
</script>

<style scoped>

</style>
module.exports = {
    api_url: "http://localhost:8080/api",
    endoor_url: "http://localhost:8080/endoor",
    parent_role_id: 8,
    common_user_id: 9,
    child_role_id: 10,
    admin_role_id: 11,
    max_hours_week: 16,
    min_hours_week: 12,
    inDev: true,
}

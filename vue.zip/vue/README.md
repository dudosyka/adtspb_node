# Adt lk vue app

#How to use components
```
  import AuthPlate from '../components/AuthPlate.vue'

  <AuthPlate title="Hello, World!"/>

  components: {
    AuthPlate
  }
```
